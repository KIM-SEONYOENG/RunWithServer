package com.example.runwith.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.runwith.R;

public class TermsActivity extends AppCompatActivity {
    CheckBox checkBox;
    CheckBox checkBox1;
    CheckBox checkBox2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms);

        setLayout();

        //모두 선택 누르면 약관1, 2 다 동의되게
        if (checkBox.isChecked() == true) {
            checkBox1.setChecked(true);
            checkBox2.setChecked(true);
        }
        //약관1이나 약관2가 체크 풀리면 모두 선택도 풀리게
        if (checkBox1.isChecked() == false || checkBox2.isChecked() == false) {
            checkBox.setChecked(false);
        }

    }

    public void setLayout() {
        checkBox = findViewById(R.id.checkBox);
        checkBox1 = findViewById(R.id.checkBox1);
        checkBox2 = findViewById(R.id.checkBox2);
    }

    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.BtnClose:
                Intent resultIntent = new Intent();
                resultIntent.putExtra("result data", "terms ok");
                setResult(RESULT_OK, resultIntent);
                finish();
        }
    }
}
